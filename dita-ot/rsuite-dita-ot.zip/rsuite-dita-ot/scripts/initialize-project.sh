#!/bin/bash

# First we calculate the PROJECT_HOME based on this script's location
progname=`basename "$0"`

# need this for relative symlinks
while [ -h "$PRG" ] ; do
  ls=`ls -ld "$PRG"`
  link=`expr "$ls" : '.*-> \(.*\)$'`
  if expr "$link" : '/.*' > /dev/null; then
  PRG="$link"
  else
  PRG=`dirname "$PRG"`"/$link"
  fi
done

PROJECT_HOME=`dirname "$PRG"`/..

# Make it fully qualified, before proceeeding
PROJECT_HOME=`cd "$PROJECT_HOME" && pwd`

# CD into the scripts directory
cd ${PROJECT_HOME}/scripts/groovy

host="localhost"
port="8080"
user="ekimber"
pw="dontcare"

adminHome=~/workspace/rsuite-admin-client/target/dist/bin/
args="-U $user -P $pw -h $host -p $port"

echo args=$args
# Now run the scripts

# NOTE: create conf/project.properties and set the locations for the 
#       hot folders

${adminHome}rsuite-admin.sh run $args -s LoadDtds.groovy
${adminHome}rsuite-admin.sh run $args -s ConfigureLayeredMetadata.groovy
${adminHome}rsuite-admin.sh run $args -s ImportWorkflows.groovy
${adminHome}rsuite-admin.sh run $args -s DefineWorkflowContextMenuItems.groovy
${adminHome}rsuite-admin.sh run $args -s ConfigureHotFolders.groovy
${adminHome}rsuite-admin.sh run $args -s PreloadContent.groovy



// Configure hot folders
// -----------------------------------------------------------------------
def projectDir = new File(scriptFile.absolutePath).parentFile.parentFile.parentFile
def props = propertyFactory.find(new File(projectDir, "conf/project.properties"))

def hotFolderToWorkflowMap = [
  (props.getNonEmpty("ingestion.word.hotfolder.dir")): "ASTD Article Word to XML to InDesign",
  (props.getNonEmpty("ingestion.books.hotfolder.dir")): "Import ASTD Book",
]

rsuite.login()

hotFolderToWorkflowMap.each { entry -> rsuite.removeHotFoldersByProcessDefinition(entry.value)

	if (entry.key) { 
		println "[INFO] Set hotfolder for workflow ${entry.value}: ${entry.key}"; 
		rsuite.setHotFolder(entry.key, entry.value, true); 
	} 
};

rsuite.logout()

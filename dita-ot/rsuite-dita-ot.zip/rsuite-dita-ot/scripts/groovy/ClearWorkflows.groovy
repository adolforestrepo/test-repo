// Groovy script to clear workflows.


rsuite.login();

rsuite.removeAllProcessDefinitions();
rsuite.removeAllHotFolders() 

rsuite.logout();



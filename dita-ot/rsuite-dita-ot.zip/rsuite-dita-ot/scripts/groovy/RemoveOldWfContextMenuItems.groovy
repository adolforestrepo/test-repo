/**
 * Remove old workflow-specific context menu items.
 * Context menu items are now defined in rsuite-plugins.xml
 */

import com.reallysi.rsuite.remote.api.*;

rsuite.login()

// -----------------------------------------------------------------------

println "REMOVING Generate XML for Article workflow...";

try {
    rsuite.removeProcessDefinitionContextMenuItem("ASTD Docx to XML");
} catch (Exception e) {
    println "EXCEPTION IGNORED: " + e;
}

println "REMOVING Generate InDesign for Article workflow...";

try {
    rsuite.removeProcessDefinitionContextMenuItem("ASTD Article to InDesign");
} catch (Exception e) {
    println "EXCEPTION IGNORED: " + e;
}
	
rsuite.logout();

import com.reallysi.rsuite.client.api.* 
import com.reallysi.rsuite.remote.api.*

// -----------------------------------------------------------------------

rsuite.login();

def infos = rsuite.getSchemaInfos();

infos.each { 
  String id = it.schemaId;
  Map m = rsuite.getSchemaProperties(id);
  //println "Object: ${it.uri}"; 
  Map props = it.getProperties();
  props.each() {
    key, value -> println "${key}: ${value}";
  }
  println "";
}

rsuite.logout();

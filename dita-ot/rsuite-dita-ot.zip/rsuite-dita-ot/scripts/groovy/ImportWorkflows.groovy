// Groovy script to load workflows
// -----------------------------------------------------------------------
def projectDir = new File(scriptFile.absolutePath).parentFile.parentFile.parentFile
def workflowDir = new File(projectDir, "workflow")
def rootWorkflowDir = new File(workflowDir, "root")

println " + [INFO] Workflow dir: " + workflowDir.getAbsolutePath();
rsuite.login()


results = workflowImporter.importFromDirectory(workflowDir)
results.entrySet().each {
  println "[INFO] Loaded workflow: ${it.key} (${it.value})"
}
results = workflowImporter.importFromDirectory(rootWorkflowDir)
results.entrySet().each {
  println "[INFO] Loaded workflow: ${it.key} (${it.value})"
}

rsuite.logout();

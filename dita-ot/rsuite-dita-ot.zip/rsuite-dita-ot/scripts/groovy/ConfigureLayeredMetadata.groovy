// Configure layered metadata:
import com.reallysi.rsuite.admin.importer.*
import com.reallysi.rsuite.client.api.*
import com.reallysi.rsuite.remote.api.*

rsuite.login();
lmDefs = rsuite.getLayeredMetaDataDefinitionInfos();
fields = [:];

def reportMetaDataMap(map) {
  def fieldName = map["name"];
  println "Metadata field: \"" + fieldName + "\""
  map.entrySet().each {
    def key = it.getKey();
    if (key != "name") {
      println "  " + key + "=" + it.getValue();
    }
  }
}

lmDefs.getMapList().each {

  def map = it.convertToMap() 
  def fieldName = map["name"];
  fields[map["name"]] = map["type"];
  reportMetaDataMap(map);
}

// return;

def addOrReplaceLMDDefinition(lmdName, associatedElements, allowedValues) {
  println " + [INFO] Metadata field \"" + lmdName + ":";
  if (fields.containsKey(lmdName)) {
    println " + [INFO]   Field exists, removing existing definition...";
    rsuite.removeLayeredMetaDataDefinition(lmdName);
  }
  println " + [INFO]   Creating new definition for \"" + lmdName + "\"...";
  println " + [INFO]     associated elements: " + associatedElements;
  println " + [INFO]     allowed values: " + allowedValues;
  def lmd = new LayeredMetaDataDefinition(lmdName, "string", associatedElements, allowedValues);
  rsuite.addLayeredMetaDataDefinition(lmd);
}

println "Updating definitions"

def elemTypes = ["article", 'CONTENT-ASSEMBLY', 'CANODE', 'NONXML'];

/**
 * article-status is the workflow status of an article  within the article development business process
 * 
 */
addOrReplaceLMDDefinition("status",
                          elemTypes, 
                          ["new",           /* Object is newly created or imported */
                           "with_author",   /* Component created by author but not yet sent to the editor */
                           "first_edit",    /* "content edit" task */
                           "returned-to-author", /* Has been returned to author for work, questions, etc. */
                           "second_edit",   /* "copy edit" task */
                           "under_review", 
                           "approved_for_publication",
                           "published",
                           "hold",
                           "spiked"
                           ])

def approvalValues = ["approval-pending",
                      "approved",
                      "rejected"];

addOrReplaceLMDDefinition("approved-for-publication",
                          elemTypes, 
                          approvalValues)
                          
addOrReplaceLMDDefinition("AuthorFirstName",
                          elemTypes, 
                          null)

addOrReplaceLMDDefinition("AuthorLastName",
                          elemTypes, 
                          null)

addOrReplaceLMDDefinition("AuthorEmail",
                          elemTypes, 
                          null)

                          
                          
                          
/**
 * ca-type provides a semantic type for CA instances, e.g., "issue". 
 */
addOrReplaceLMDDefinition("ca-type",
                          ['CONTENT-ASSEMBLY','CANODE'], 
                          ["issue",
                           "article",
                           "none",
                           "other"  
                           ])

/**
 * Allow storing of process ID.
 */
addOrReplaceLMDDefinition("article-process-id",
                          ['CONTENT-ASSEMBLY','CANODE'],
                          null) 

/**
 * manual-status is the workflow status of an manual within the manual publication business process.
 * These status values apply to both the manual content assembly and any artifacts generated from
 * it (e.g., InDesign docs, PDF docs).
 */
addOrReplaceLMDDefinition("issue-status",
                          ['CONTENT-ASSEMBLY', 'CANODE', 'NONXML'], 
                          ["in_development",
                           "under_content_review",
                           "in_production", /* Manual is being prepared by Design.  */ 
                           "second_edit",
                           "approved_for_publication",
                           "published"
                           ])
                           

/**
 * The caption to use for graphics used in an issue by not linked into a specific article.
 */
addOrReplaceLMDDefinition("media-caption",
                          ["NONXML"], 
                          null)
                           
/* End of Script */                          

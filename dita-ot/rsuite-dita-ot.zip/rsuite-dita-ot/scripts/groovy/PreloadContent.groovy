// Groovy script to load some sample content.


File projectDir  = new File(scriptFile.absolutePath).parentFile.parentFile.parentFile;
File sampleDataDir   = new File(projectDir,  "sample_data");
File templatesDir    = new File(projectDir,  "templates");
File taxXmlDir       = new File(projectDir,  "taxonomy/xml");
File taxonomyXml     = new File(taxXmlDir, "taxonomy.xml");

rsuite.login();

// Set up the browse tree structure and add stuff to it:

def caMoid;
def moid;

// rsuite.createFolder("/","Books"); 
rsuite.createFolder("/","Magazines"); 
rsuite.createFolder("/Magazines/", "T and D"); 

result = rsuite.createContentAssembly("/Magazines/T and D", "Resources", true);
caMoid = result.getEntryValue("moid");

result = rsuite.createContentAssembly("/Magazines/T and D", "Templates", true);
caMoid = result.getEntryValue("moid");

result = rsuite.loadNonXmlFromFile(new File(templatesDir, "indesign/T-and-D-InDesign-Styles.indd"), false, true);
moid = result.getEntryValue("moid")
rsuite.addResourceToAssembly(caMoid, moid)  

result = rsuite.loadNonXmlFromFile(new File(templatesDir, "indesign/T-and-D-InDesign-Template.indd"), false, true);
moid = result.getEntryValue("moid")
rsuite.addResourceToAssembly(caMoid, moid)  

result = rsuite.loadNonXmlFromFile(new File(templatesDir, "word/T-and-D_Article.dotx"), false, true);
moid = result.getEntryValue("moid")
rsuite.addResourceToAssembly(caMoid, moid)  

taxId = rsuite.getIdByAlias("taxonomy.xml");
if (taxId == null) {
  println "[INFO] Loading taxonomy.xml...";
  rsuite.createFolder("/", "Resources"); 
  result = rsuite.createContentAssembly("/Resources", "Taxonomies", true);
  caMoid = result.getEntryValue("moid");
  result = rsuite.loadXmlFromFile(taxonomyXml, (String[])["taxonomy.xml"],
                                  true, true);
  moid   = result.getEntryValue("moid");
  rsuite.addResourceToAssembly(caMoid, moid)  
  println "[INFO] taxonomy.xml added: " + moid;

} else {
  println "[INFO] Skipping taxonomy.xml: Already exists: " + taxId;
  /*
  rsuite.checkOut(taxId);
  try {
    result = rsuite.updateXmlFromFile(taxId, taxonomyXml,
                                      (String[])["taxonomy.xml"]);
  } finally {
    rsuite.checkIn(taxId, "Preload update via script", 1);
  }
  */
}

rsuite.createFolder("/", "Views"); 


// File dirToLoad = manualsDir;

//def dirToLoad = new File(sampleDataDir, )
//
//createCAHierarchyFromPath(dirToLoad, "/" + contentRootFolder, "", 0)


	
rsuite.logout();


def createCAHierarchyFromPath(dirFile, parentPath, parentMoid, level) {
	  dirFile.eachFile { file ->
	    if (file.name != "CVS" && file.name != "alleycat.xml") {
	      if (file.isDirectory())
	      {
	        (0..(level*2)).each { print "  "}
	        println "CA: ${file.getName()}"
	        if (level == 0)
	          result = rsuite.createContentAssembly(parentPath, file.getName(), true)
	        else
	          result = rsuite.createContentAssemblyNode(parentMoid, file.getName())
	        def caMoid = result.getEntryValue("moid")
	        // Recursively call ourself for directory
	        createCAHierarchyFromPath(file, parentPath+file.getName()+"/", caMoid, 1+level)
	      }
	      else
	      {
	        (0..(level*2)).each { print "  "}
	        File aFile = new File(dirFile, file.getName());
	        
	        if(aFile.name.endsWith(".xml")) {
	        	println "loading XML file: ${file.getName()}"
	        	result = rsuite.loadXmlFromFile(aFile, true, true);
		        
	        }
	        else {
	        	println "loading nonxml file: ${file.getName()}"
	        	result = rsuite.loadNonXmlFromFile(aFile, false, true);
	        }
	        
	        def moid = result.getEntryValue("moid")
	        rsuite.addResourceToAssembly(parentMoid, moid)        
	      }
	    }
	  }
	}


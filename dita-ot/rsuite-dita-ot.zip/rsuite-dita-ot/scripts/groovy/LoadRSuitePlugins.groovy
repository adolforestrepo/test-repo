// Groovy script to load plugins

class Global {
  static scriptDir;
  static projectDir;
  static pkgPluginsDir;
  static targetDir;
  static prjLibDir;

  static public initVars(baseFile) {
    scriptDir     = new File(baseFile.absolutePath).parentFile;
    projectDir    = scriptDir.parentFile.parentFile;
    pkgPluginsDir = new File(projectDir, "rsuite-plugins");
    targetDir     = new File(projectDir, "target");
    prjLibDir     = new File(new File(projectDir, "java"), "lib");
  }
}
Global.initVars(scriptFile);


rsuite.login();

deployPlugin(findPlugin("astd-plugin.jar"));
if (true) {
  deployPlugin(findPlugin("dita2indesign-rsuite-plugin.jar"));
  deployPlugin(findPlugin("dita4publishers-rsuite-plugin.jar"));
  deployPlugin(findPlugin("rsuite-dita-support-plugin.jar"));
}

rsuite.logout();

def deployPlugin(file) {
	println " + [INFO] Deploying ${file.getName()}...";
	rsuite.deployPlugin(file);
}

def findPlugin(file) {
  def f = new File(Global.pkgPluginsDir, file);
  if (f.exists()) return f;
  f = new File(Global.targetDir, file);
  if (f.exists()) return f;
  return new File(Global.prjLibDir, file);
}

#!/bin/sh

progname=`basename "$0"`

# need this for relative symlinks
while [ -h "$PRG" ] ; do
  ls=`ls -ld "$PRG"`
  link=`expr "$ls" : '.*-> \(.*\)$'`
  if expr "$link" : '/.*' > /dev/null; then
  PRG="$link"
  else
  PRG=`dirname "$PRG"`"/$link"
  fi
done

PROJECT_HOME=`dirname "$PRG"`/..

PROJECT_HOME=`cd "$PROJECT_HOME" && pwd`
LIB=${PROJECT_HOME}/java/lib/

CP=${PROJECT_HOME}/build:${LIB}commons-logging.jar:${LIB}log4j.jar:${LIB}saxon9.jar:${LIB}saxon9-dom.jar:${LIB}commons-io.jar



java -cp ${CP} com.astd.rsuite.utils.Docx2Xml $1 $2